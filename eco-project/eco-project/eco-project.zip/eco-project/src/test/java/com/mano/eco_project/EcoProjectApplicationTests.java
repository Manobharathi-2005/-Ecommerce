package com.mano.eco_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
